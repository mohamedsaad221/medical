
import 'dart:ui';

import 'package:medical/shared/network/local/shared_pref.dart';

String? lang = CacheHelper.getData(key: 'lang');
// String? lang = 'en';

// String? uId = CacheHelper.getData(key: 'uId');
String? uId = '';

Color primaryColor = const Color.fromRGBO(80, 203, 244, 1.0);
